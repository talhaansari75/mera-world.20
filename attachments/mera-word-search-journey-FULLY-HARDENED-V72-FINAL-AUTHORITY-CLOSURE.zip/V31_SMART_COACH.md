# V31 — Smart Coach & Local Personalization

Implemented a local-first coaching layer that derives gameplay recommendations from existing save statistics.

## Features
- Personalized mode recommendations based on win rate and hint usage.
- Streak protection guidance.
- Perfect-clear/mastery guidance.
- Survival/challenge recommendations for strong players.
- No new personal data collection and no network call for coaching.
- New `coach` ScreenId and More menu entry.

## QA
- Static integration checks cover ScreenId, route, menu entry, and coach module imports.
- Full dependency build/typecheck remains environment/deployment dependent when packaged node_modules are absent.
