# V57 Complete Gap Closure

This release closes the remaining gameplay gaps identified in the V56 audit in one pass.

## Fixed
- Removed duplicate `petProfile` import from the main game store.
- Daily challenges now carry their variant into puzzle data.
- Speed Day uses a 90-second challenge clock.
- Hidden Word Day activates fog presentation in the daily grid.
- Ice Day guarantees an Ice tile.
- Bomb Day guarantees a Bomb tile.
- Combo/Perfect/Treasure/Hidden variants retain condition-aware reward bonuses.
- Daily rewards are single-claim per calendar day; replaying the same daily does not duplicate daily currency/pet-XP rewards.
- Added daily streak persistence and migration.
- Boss combat now rejects locked/non-boss levels.
- Boss completion screen now exposes an explicit Guardian Battle handoff.
- Combat fallback searches backward for a real unlocked Boss Gate.
- Boss/world collectible trophy IDs are awarded idempotently into inventory on local completion.
- Node strip-types regression coverage was hardened with explicit relative `.ts` imports in the game library.
- Added tests covering forced Ice/Bomb daily mechanics.

## Validation
- Combined campaign/boss/pet/daily suite: **11/11 passed**.
- Preview script syntax check: passed.
- Full TypeScript typecheck remains environment-limited because this workspace does not contain installed `@types/node` and `vite/client` packages; no claim of a full production compile is made.
