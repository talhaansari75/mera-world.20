# V51 — Functional Special Tile Mechanics

## Scope
Deepens the Fun & Visual Polish phase by turning the existing special-tile markers into deterministic gameplay mechanics.

## Mechanics
- **Ice:** selecting a path through an ice tile triggers a short 900ms input freeze. The board visually enters a frozen state and ignores new pointer starts during the freeze.
- **Locked:** locked tiles are hard obstacles. Drag paths are clipped immediately before the lock; keyboard/tap selection cannot start on a locked tile.
- **Bomb:** selecting a path through a bomb triggers a deterministic 3x3 blast presentation around the bomb. The effect is tied to the selected path, not a passive animation.
- **Moving:** moving obstacles relocate deterministically between fixed 1.4s ticks. Their movement uses only the preselected filler-tile anchors, so target word paths remain solvable.

## Safety / fairness
- Special tiles are deterministic from the puzzle seed.
- Special tiles are generated only on filler cells, never on target word placements.
- Reduced-motion users receive no special animation loops.
- No client-side special mechanic grants currency or premium entitlement.
- Existing server-authoritative word-path verification remains unchanged.

## QA
Added `src/lib/game/specialTiles.test.ts` covering deterministic placement, target-cell exclusion, lock clipping, special detection, and moving relocation.
