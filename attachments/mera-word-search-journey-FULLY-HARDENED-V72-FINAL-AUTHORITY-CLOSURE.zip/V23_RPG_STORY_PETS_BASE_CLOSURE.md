# V23 — RPG / Story / Pets / Base Closure

## Closed in this pass
- Pet upgrade action with rarity-aware cost and max-level enforcement.
- Pet upgrade UI connected to the existing Pets screen.
- Boss combat victory now grants XP plus deterministic crafting materials in addition to coins.
- Existing combat, dialogue, story chapter unlocks, building upgrades, crafting, equipment and pet systems remain connected to the Zustand save.
- Combat rewards feed the same economy used by crafting/equipment, creating a repeatable RPG loop.

## Verification
- Source-level integration check: PASS
- Pet upgrade path: PASS
- Combat victory reward path: PASS
- Existing V22 mode/content checks retained.

## Production boundary
Real-time server-authoritative combat, anti-cheat and cloud persistence still require a deployed backend; this pass does not pretend local Zustand state is authoritative.
