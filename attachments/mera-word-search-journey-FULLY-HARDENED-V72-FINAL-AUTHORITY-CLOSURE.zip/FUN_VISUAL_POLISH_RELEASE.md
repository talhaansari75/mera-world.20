# Fun & Visual Polish Phase — Release Notes

Implemented in this hardened build:

- Premium animated loading screen with progress and branded journey message.
- Home screen redesigned around **Continue Journey** as the primary CTA.
- Current level, world, rank, journey progress, route nodes, and equipped companion surfaced above the fold.
- Daily reward modal with 7-day streak framing and claim CTA.
- Six headline journey worlds renamed to Green Meadows, Crystal Caves, Ancient Desert, Frozen Kingdom, Shadow Forest, and Sky Islands.
- World-specific procedural music palettes selected from the level's journey world.
- Gameplay combo presentation with exact x2 at 3 consecutive finds and x3 at 5+.
- Combo-sensitive sound escalation.
- Fast-clear bonus and golden milestone bonus (every 5 found words) added to completion rewards.
- Hidden bonus-word path retained and surfaced through gameplay reward flow.
- Premium tile polish: depth, glow, found pulse, wrong-selection shake, and deterministic special tile visual markers for ice/locked/bomb/moving cells on safe filler cells.
- Completion fireworks added to the win experience.
- Existing haptics, accessibility/reduced-motion settings, authoritative gameplay verification, streak, pet perks, daily systems, missions, and world systems remain intact.

## Production hardening repair

- `GameSessionV5.stateJson` added to Prisma schema.
- Added V50 reconciliation migration to add `game_sessions_v5.state_json` and convert V5 JSON text columns to PostgreSQL `jsonb`.
- The reconciliation is idempotent for the additive column and reviewed as a migration rather than using `prisma db push`.

## Verification limitation

Dependency installation could not complete within the available execution window, so a full `tsc`, lint, Prisma client generation, browser build, and database-backed E2E run could not be executed in this environment. The source and migration changes were inspected directly after modification.
