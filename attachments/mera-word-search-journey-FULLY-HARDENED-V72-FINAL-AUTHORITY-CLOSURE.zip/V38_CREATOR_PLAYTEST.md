# V38 — Creator Playtest

Adds a real local playtest loop after V37 Playable Preview. Creator drafts can be selected and played using the existing GridBoard input engine. The playtest tracks completion, elapsed time, mistakes, and a deterministic 0–100 score, then stores up to 50 local playtest results.

## Flow

Creator Studio → Playable Preview Studio → Creator Playtest → publish/review.

## Privacy / offline

No new network calls or telemetry. Results stay in browser localStorage. The feature works offline.
