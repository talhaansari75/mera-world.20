# V22 — Gameplay Modes Closure

This pass closes the major gameplay-mode rule gap by enforcing mode rules at the gameplay action boundary rather than only describing them in metadata.

## Implemented
- Diagonal mode rejects non-diagonal submitted paths.
- Orthogonal mode rejects diagonal submitted paths.
- Reverse-only mode requires the reverse traversal of a placed word.
- Mirror mode remains a visual presentation mode; the board and word list mirror consistently.
- Fog mode remains a visibility mechanic driven by GridBoard.
- No-hints/hardcore/precision mistake rules remain enforced in the store.
- Survival/precision/hardcore max-mistake limits remain enforced.
- Random-rules has a deterministic rule selector utility for future UI display/telemetry.
- Existing timed/blitz/rush/speedrun/marathon timers and word-count modifiers remain in `levels.ts`.
- Existing reward multipliers remain in `modeRules.ts`.

## QA
`node scripts/v22-mode-qa.mjs` checks that the new gameplay rule boundary is actually wired into the store. Full typecheck/build still requires the project's dependencies and deployment environment.
