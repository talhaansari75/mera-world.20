# V40 — Creator Release Package

Adds a final local delivery artifact after Publish Readiness. Creators can select a draft, generate a portable JSON release package containing the draft plus the readiness snapshot, and export it from the browser.

## Integrity

The canonical draft/readiness payload is hashed with Web Crypto SHA-256 when available. A deterministic FNV-1a fallback is used when SubtleCrypto is unavailable. The digest is informational and supports artifact identity checking; it is not a server authorization signature.

## Flow

Creator Studio → Playable Preview → Creator Playtest → Publish Readiness → Release Package.

No automatic publishing, new telemetry, or client-side secrets are introduced.
