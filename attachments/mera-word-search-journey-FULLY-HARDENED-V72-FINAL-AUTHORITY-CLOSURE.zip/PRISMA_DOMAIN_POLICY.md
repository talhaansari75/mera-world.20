# Prisma domain policy

Controlled state domains are enforced at the PostgreSQL boundary with CHECK constraints and application validators. Provider, game mode, event type, target type, and role/permission names remain strings where the domain is intentionally extensible or broker-defined. Turning those fields into hard Prisma enums would make OAuth/payment providers and future game modes a schema migration for every new value.

The production gate therefore treats this as an intentional design decision rather than an unfinished enum migration.
