# V9 Real Integration Pass

This release prioritizes wiring over file-count inflation.

## Integrated
- Existing Zustand gameplay store now installs the V9 gameplay bridge during hydration.
- Level/daily/endless starts emit a common `level:start` event.
- `submitPath` now passes bounded-input and duplicate-action guards before puzzle evaluation.
- Existing game events feed the V9 telemetry bridge for starts, found words, misses, completes and failures.
- Existing app root mounts a minimal V9 session persistence component.

## Verification
- Added unit coverage for the new path guard.
- Full dependency install/build should be run in a normal development environment; the packaging environment may time out while installing the full dependency graph.

## Honest scope
This is an integration pass, not a claim that every product item is production complete. External providers and deployment infrastructure remain configuration-dependent.
