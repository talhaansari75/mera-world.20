# Mera Word Search Journey — V59 Security & Gameplay Closure

## Fixed in V59

- Daily challenges are server-bound to the canonical UTC day and deterministic variant.
- A daily result is checked before session creation and again inside the completion transaction.
- The unique `(userId, dayKey)` daily result is therefore a server-side one-claim gate; concurrent completion attempts cannot both receive the daily reward.
- Speed Day is enforced against the server session timer and the explicit 90-second objective.
- Ice/Bomb Daily variants now place their signature hazard on a real target-word cell, so solving the daily necessarily interacts with the mechanic. The server derives the hazard map from the signed session puzzle and records special hits from submitted paths.
- Daily Ice/Bomb objectives require the corresponding hazard to be triggered.
- Guardian boss classification is now restricted to the six narrative World Gate endpoints. Ordinary 25-level milestones are no longer treated as bosses.
- Client and server therefore share the same `isBoss()` campaign definition.

## Verification

- Targeted campaign, boss, engagement, daily, and special-tile tests: **16/16 PASS**.
- ZIP integrity: **PASS**.
- Full production dependency-backed build/typecheck remains an environment verification step and is not falsely marked as passed when dependencies are unavailable.
