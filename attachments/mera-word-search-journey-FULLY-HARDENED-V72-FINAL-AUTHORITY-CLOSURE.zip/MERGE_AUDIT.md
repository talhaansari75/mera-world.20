# Mera Word Search Journey — Merge & Audit

## Merge basis

- Primary base: `mera-word-search-journey-v51-ads-subscription.zip`
- Production-hardening metadata/artifacts retained from `mera-word-search-journey-v49-production-hardened.zip`.
- The v51 code path was kept for Prisma enums, authorization checks, CI hardening/audits, and the ads/subscription integration.

## Fixes applied during audit

1. Fixed a syntax error in `src/lib/server/cloud.ts` that made TypeScript parsing fail.
2. Fixed cloud-save persistence to respect Prisma's `String` `saveJson` column (stringify on write, parse on read).
3. Fixed BigInt revision increments to use `1n`.
4. Fixed `src/lib/v26/progression/serverRewards.ts` to serialize/deserialize `saveJson` consistently and use BigInt revision increments.
5. Fixed `src/components/v13/PaymentsScreen.tsx` to use the actual `productId` entitlement field.
6. Fixed `scripts/prisma-semantic-data-verify.mjs` so its allowed currency/status values match the Prisma schema (`USD/EUR/GBP/PKR` and `open/playing/closed`).

## Validation

- JavaScript/MJS syntax check: PASS.
- `check:prisma`: PASS.
- `check:prisma:strict`: PASS.
- Prisma migration structure audit: PASS — 32 mapped tables checked.
- Raw/dynamic Prisma SQL scan: PASS.
- Migration policy scan: PASS.
- Ads config audit with no publisher configured: PASS; ads remain safely disabled until deployment configuration is supplied.
- Full `npm test`: 180/188 tests passed. 8 failures are existing Grok PWA fixture/identity expectations caused by the repository's baked `src/lib/og/site.json` identity (`Mera Word Search Journey`) versus generic test expectations (`Wild Race`/document-title fixtures). They are not related to the Prisma, ads, subscription, or cloud-save fixes above.
- Full dependency-backed TypeScript/build validation could not be completed because `npm ci` timed out in the execution environment. A subsequent `tsc` run confirmed the original syntax errors were removed; remaining diagnostics were dependency/type-definition availability errors.

## Deployment notes

Set `VITE_ADSENSE_PUBLISHER_ID` only when AdSense/H5 ads are actually configured. Keep payment verification server-side; the browser must not self-grant `ad_free` entitlements.
