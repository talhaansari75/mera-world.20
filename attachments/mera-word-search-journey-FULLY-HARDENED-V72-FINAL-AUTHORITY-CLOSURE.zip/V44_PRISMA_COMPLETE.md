# V44 — Prisma Complete Persistence Hardening

## Closed V43 gaps

1. **Complete schema:** Prisma models now cover Better Auth plus the application
   tables from V42's SQL migrations.
2. **Safe V42 adoption:** the adoption migration is additive and idempotent;
   preflight rejects incompatible existing types before migration.
3. **Build isolation:** `npm run build` is frontend/build only. DB changes happen
   only through `npm run db:migrate`.
4. **Migration history:** Prisma `_prisma_migrations` is authoritative; the
   release migration records `_prisma_app_adoption` as an application adoption
   marker.
5. **Real auth flow test:** `npm run db:auth-smoke` exercises Better Auth signup,
   verifies Prisma user/account/session persistence, signs in, and requires a
   session cookie.
6. **No PGlite runtime:** local/preview/production all use PostgreSQL via Prisma.
7. **No Kysely runtime:** the compatibility SQL facade now routes through
   PrismaClient; Kysely/PGlite dependencies and dialect are removed.
8. **Deployment reproducibility:** package manifest is complete for Prisma. A
   lockfile could not be regenerated in this build environment because npm
   registry DNS (`registry.npmjs.org`) was unavailable. The archive therefore
   deliberately does not ship a fabricated lockfile/checksum set.
9. **Future auth relations:** Prisma schema includes profile ownership and
   app-level relations for saves, creator content, reviews, entitlements and
   push subscriptions.
10. **DB smoke/preflight:** `db:preflight`, `db:verify`, `db:smoke`, and
    `db:auth-smoke` provide separate connectivity, schema, and auth checks.

## Release sequence

```bash
npm install
npx prisma generate
npm run db:migrate
npm run db:verify
npm run db:smoke
npm run db:auth-smoke
npm run typecheck
npm run build
```

Do not run database migration as part of a frontend build or use `prisma db push`
on production.
