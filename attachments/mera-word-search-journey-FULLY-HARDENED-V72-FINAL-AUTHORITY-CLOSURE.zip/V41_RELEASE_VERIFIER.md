# V41 — Creator Release Verifier

V41 closes the creator delivery loop with a local release-package verification screen.

## Included
- Import a V40 creator release JSON package.
- Validate the expected release schema/version.
- Validate readiness score shape and bounds.
- Recompute the package's canonical integrity digest and compare it with the embedded digest.
- Show clear verified/failed status and issues.
- No upload, telemetry, or new secret is required.

## Security boundary
The verifier checks package integrity and structure; it is not a server authorization signature or proof of publisher identity.
