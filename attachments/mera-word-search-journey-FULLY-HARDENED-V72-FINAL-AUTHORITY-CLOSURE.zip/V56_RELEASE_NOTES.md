# V56 — Daily Challenge Variations

V56 extends the V54/V55 engagement stack with deterministic daily challenge variations.

## Implemented
- 7 daily challenge variants: Speed, Combo, Hidden Word, Ice, Bomb, Perfect, Treasure.
- Variant selection is deterministic from the UTC day key.
- The selected challenge is stored on the active daily PlaySession, so it cannot change mid-puzzle.
- Daily completion reward multiplier is bounded at 1.5x.
- Perfect, combo and treasure variants receive condition-aware bonus boosts.
- Daily screen now previews today's variation and its base reward boost.
- Added dedicated daily and aggregate engagement test commands.

## Validation
- V56 daily tests: 2/2 pass.
- Existing boss tests: 3/3 pass.
- Existing engagement tests: 3/3 pass.
- Existing V52 journey tests: 2/2 pass.
- Combined relevant regression suite: 10/10 pass.
- Full TypeScript/build validation remains dependent on the project's installed npm dependencies.
