# V52 — Complete Six-World Journey

The main journey is now a six-world campaign across levels 1–2000. Each world has a story objective, hero, five map milestones, a world-end boss gate, and a one-time completion chest.

1. Green Meadows — The Ink Stag
2. Crystal Caves — The Crystal Wyrm
3. Ancient Desert — The Sand Colossus
4. Frozen Kingdom — The Frost Queen
5. Shadow Forest — The Shadow Beast
6. Sky Islands — Atlas Prime

Boss gates use the existing `boss` gameplay flow. Chest claims use deterministic inventory keys (`journey-chest-{world}`), so reload/import cannot duplicate a chest. Progress is derived from `unlockedLevel`, avoiding another mutable progression counter.
