# Final hardening pass

Implemented server-created gameplay sessions, server-validated word paths, server-timed completion, server-side level/energy checks, atomic reward claims, verified leaderboard recording, signed provider-agnostic payment webhooks, production auth secret fail-closed behavior, stricter telemetry payloads, and canonical all-test discovery.

## Payment configuration
Set `PAYMENT_PROVIDER` and `PAYMENT_WEBHOOK_SECRET`. The webhook endpoint is `/api/payments/webhook` and expects an HMAC-SHA256 signature in `x-payment-signature` (hex) over the exact raw JSON body. Provider-specific adapters can replace the generic HMAC boundary without changing entitlement logic.

No fake provider credentials or fake payment confirmations are included.
