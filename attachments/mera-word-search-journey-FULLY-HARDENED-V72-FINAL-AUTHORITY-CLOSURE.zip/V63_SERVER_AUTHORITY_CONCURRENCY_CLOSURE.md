# V63 — Server Authority & Concurrency Closure

## Fixed
- Serialized gameplay actions with row-level `FOR UPDATE` locking.
- Client gameplay actions now use a FIFO server-action queue instead of fire-and-forget requests.
- Pause/resume transitions are validated server-side.
- Pet energy/time modifiers are authoritative when starting sessions.
- Pet coin/XP modifiers and pet XP are authoritative at completion.
- Daily `lastDaily` and `dailyStreak` are persisted by the server.
- Normal level first-clear rewards now have durable `level-clear:<userId>:<level>` ledger keys.
- World Boss starts are serialized with a PostgreSQL advisory lock.
- Database partial unique index prevents duplicate active boss sessions per user/boss.
- Boss actions are row-locked before state transition.

## Verification
Static and focused tests must pass before release. Full production typecheck/build/E2E still requires the project's dependencies and a configured PostgreSQL environment.
