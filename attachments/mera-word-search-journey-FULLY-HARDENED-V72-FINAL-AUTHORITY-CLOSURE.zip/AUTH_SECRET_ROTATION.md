# Production auth-secret rotation

`BETTER_AUTH_SECRET` is a signing/encryption boundary. Rotation is a controlled security event, not an automatic build step.

1. Prepare the new secret (minimum 32 random characters).
2. Put the app in a controlled rollout/maintenance window.
3. Deploy the new secret.
4. Explicitly revoke existing Better Auth sessions with the reviewed Prisma admin job (`session.deleteMany({})`) if immediate invalidation is required. This is the default security policy for emergency rotation.
5. Run browser auth smoke: sign-up/sign-in, authenticated reload, logout, and old-session rejection.
6. Confirm OAuth callback and account linking still work.
7. Remove the old secret from the deployment platform.

Never print either secret in logs. Never commit secrets or put them in the Prisma schema.
