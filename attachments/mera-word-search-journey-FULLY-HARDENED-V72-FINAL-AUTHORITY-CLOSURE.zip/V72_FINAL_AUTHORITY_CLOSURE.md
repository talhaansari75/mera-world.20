# V72 Final Authority Closure

## Fixed
- Hint economy serialized per user with a PostgreSQL advisory transaction lock so concurrent gameplay sessions cannot double-spend the same coin balance.
- Online hint UI/state is committed only after the server accepts the hint action; rejected hints do not mutate revealed cells or hint counters locally.
- Duplicate/retried hint actions return authoritative current economy values for deterministic client reconciliation.
- Completion retries are replayable from the persistent `gameplay:<sessionId>` reward ledger and return the current authoritative save.
- Existing V71 invalid-action, leaderboard isolation, UUID, queue/session isolation, and coordinate-validation hardening is preserved.

## Verification
- Script regression suite: 233/233 PASS.
- `gameplay.ts` syntax: PASS.
- `store.ts` syntax: PASS.
- Security hardening audit: PASS (45 legacy routes).
- Ultimate pack check: PASS (12 required files).

## Production verification boundary
A real PostgreSQL instance, installed production dependencies, and browser automation are environment prerequisites. `npm ci --ignore-scripts --no-audit --no-fund` was attempted for 300 seconds but timed out before creating `node_modules`. Therefore this release does not falsely claim production typecheck/build, live PostgreSQL migration/concurrency, or Playwright E2E execution.

## Deployment gate
Deploy only after the target environment successfully runs the production release gate:
`npm run db:production-release`
plus the production build/typecheck and `npm run e2e:production` against a staging/production-like environment.
