# V19 — Content & Level Closure

## Closed in this pass

- Offline English lexicon now has a **9,000-word extended bank** sourced from the CMU Pronouncing Dictionary and filtered to A–Z, 3–14 characters.
- The extended bank is merged into the game's `ALL_WORDS`, so general and fallback generation can use it offline.
- Level catalog already defines **2,000 deterministic levels**, exceeding the 1,000-level target.
- Generator now uses category words first and the extended bank as a deterministic fallback, preventing late-game levels from shrinking because a category has too few eligible words.
- Existing puzzle quality validation remains in the generation loop; generated puzzles are accepted only when structural validation and quality checks pass, with a deterministic solvable fallback.
- Added `contentCoverage.ts` for machine-readable word/level/quality coverage reporting.
- Added a dependency-free V19 content QA script.

## Not claimed as closed

- 5,000 fully human-curated words per each of the 15 languages are **not** present.
- Non-English packs still use the existing native samples/shared fallback model.
- Full 2,000-level human playtest/balance pass has not been performed in this environment.
- Production build/typecheck remains dependent on installing the project's npm dependencies.

## Source attribution

The extended English bank is derived from the **CMU Pronouncing Dictionary (cmudict)** and is filtered for offline game use. See `THIRD_PARTY_NOTICES.md`.
