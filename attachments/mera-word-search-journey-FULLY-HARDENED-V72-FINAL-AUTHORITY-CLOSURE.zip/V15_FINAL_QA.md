# V15 — Final QA & Production Hardening

V15 is the final **static/integration QA pass** over the V14 workspace. It does not claim that the product is fully production-deployed or that every feature in the 1850+ specification is complete.

## Verified

- V9, V10, V11, V13 and V14 integration checks all pass.
- Core app routes for Systems, Social, LiveOps, Admin and Payments are wired.
- Gameplay lifecycle events are emitted from the Zustand game store.
- AI uses the server-side `XAI_API_KEY` path; no `VITE_XAI_API_KEY` browser path is present.
- Database configuration reads `DATABASE_URL` from server environment.
- Admin authorization reads `ADMIN_USER_IDS` from server environment.
- All 15 language codes in the V14 matrix are present.
- Daily, weekly and seasonal LiveOps cycles are present.
- Static source scan found no obvious VITE-prefixed key/secret/token/private-key variable in the audited AI server module.
- ZIP integrity was checked after packaging.

## Not claimed

- Full `npm run typecheck` / `npm run build` was not executed because this workspace does not contain installed `node_modules` in the packaging environment.
- Production database, auth, payment provider, push, WebRTC signaling, AI provider, CDN and deployment secrets still require real environment configuration.
- Real-time multiplayer depends on deployed signaling/backend infrastructure.
- Payment completion depends on a real payment provider and verified webhooks.
- The 1850+ specification is not represented as 1850 fully implemented production features; several earlier batches are contracts/foundations rather than end-to-end features.

## Run after installing dependencies

```bash
npm install
npm run check:v15
npm run typecheck
npm run build
npm test
```

`check:v15` is dependency-free and can be run immediately with Node 22+.
