# Ads + Ad-Free Subscription

## Ad network

This build is wired for **Google AdSense H5 Games Ads / H5 Ad Placement API**. The integration uses an interstitial opportunity at the natural transition from a completed level to the next level. It is intentionally not placed over the active word-search board.

Required deployment variable:

```env
VITE_ADSENSE_PUBLISHER_ID=ca-pub-XXXXXXXXXXXXXXXX
```

Do not commit a real publisher ID to source if you prefer environment-based configuration.

Google requires the H5 Games Ads program/approval and the game's domain to be configured in the AdSense account. Live ads will not appear until Google approves/serves the inventory.

## Ad-free subscription

The entitlement product ID is:

```text
ad_free
```

When the authenticated user has an active `ad_free` entitlement, the game never calls the H5 interstitial placement.

The existing payment boundary must grant/revoke this entitlement from a **server-verified provider webhook**. Do not let the browser grant itself `ad_free`.

## Placement policy

- Interstitial only at the level-complete → next-level transition.
- Minimum local cooldown: 2 minutes.
- Never show ads over active puzzle interaction.
- No ad click incentives.
- No startup ad.
- No ad after leaving the game.
- Google may additionally suppress an ad because of frequency caps, consent, inventory, or user eligibility.

## ads.txt

After AdSense gives the account's exact ads.txt line, publish it at the domain root. Do not invent the publisher ID or seller line. Google recommends ads.txt for authorized seller transparency.
