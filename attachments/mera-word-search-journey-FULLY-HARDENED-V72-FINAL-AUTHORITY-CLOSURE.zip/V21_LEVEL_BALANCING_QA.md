# V21 — Level Balancing & Automated QA

## Closed in this pass

- 2,000-level world coverage is continuously mapped from level 1 through MAX_LEVEL.
- Added reusable level-band definitions for onboarding, foundation, advanced, expert, master, legend, nightmare, and apex tiers.
- Added `difficultyScore()` for a deterministic 0–100 difficulty estimate based on grid pressure, word count, word-length spread, time pressure, and boss status.
- Added `validateLevelSpec()` and `levelReport()` for tooling and future admin/creator QA surfaces.
- Hardened generator fallback so dense levels use multiple orthogonal lanes before giving up on a placement.
- Existing puzzle validity and quality checks remain the final gate for generated puzzles.
- Added dependency-free V21 structural QA script.

## Verification

`node scripts/v21-level-qa.mjs` → PASS

The QA verifies MAX_LEVEL, continuous world coverage, minimum world count, and presence of the quality/fallback generation path.

## Remaining boundary

This pass closes the **level-spec and generation architecture**. It does not claim that every one of the 2,000 generated puzzles has been manually play-tested or that every language has thousands of professionally curated words. Those are separate content-review and production deployment tasks.
