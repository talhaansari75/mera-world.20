# V42 — Creator Release Archive

V42 adds a local release catalog after V41 verification.

## Included
- Imports JSON release packages and refuses to archive packages that fail V41 verification.
- Stores up to 100 verified releases in localStorage.
- Deduplicates entries by integrity digest.
- Displays title, readiness state/score and integrity digest.
- Removes individual archive entries.
- Exports a lightweight JSON catalog manifest.
- Adds `releaseArchive` routing and More-menu entry.

## Security boundary
The archive is device-local metadata storage. It does not establish server authorization, publisher identity, or cryptographic signing. Verification remains the V41 schema/readiness/integrity check.
