import { test, expect } from '@playwright/test';

const baseURL = process.env.E2E_BASE_URL;
const email = process.env.E2E_TEST_EMAIL;
const password = process.env.E2E_TEST_PASSWORD;
const signupEmail = process.env.E2E_SIGNUP_EMAIL;
const signupPassword = process.env.E2E_SIGNUP_PASSWORD || password;

test.skip(!baseURL || !email || !password, 'Set E2E_BASE_URL, E2E_TEST_EMAIL and E2E_TEST_PASSWORD for production auth E2E.');

test('production sign-in/session/reload/logout round-trip', async ({ page }) => {
  await page.goto(`${baseURL}/login`);
  await page.getByPlaceholder('Email').fill(email!);
  await page.getByPlaceholder(/Password/i).fill(password!);
  await page.getByRole('button', { name: /sign in with email/i }).click();
  await expect(page).toHaveURL(/\/$/);
  await page.reload();
  await expect(page).toHaveURL(/\/$/);
  const cookies = await page.context().cookies();
  expect(cookies.some(c => c.name.includes('grok-auth.session'))).toBeTruthy();
  await page.goto(`${baseURL}/login`);
  await expect(page).toHaveURL(/\/$/);
});

test('production multi-device sessions survive independent logout', async ({ browser }) => {
  const a = await browser.newContext(); const b = await browser.newContext();
  try {
    for (const ctx of [a,b]) {
      const p=await ctx.newPage(); await p.goto(`${baseURL}/login`);
      await p.getByPlaceholder('Email').fill(email!); await p.getByPlaceholder(/Password/i).fill(password!);
      await p.getByRole('button', { name: /sign in with email/i }).click(); await expect(p).toHaveURL(/\/$/);
    }
    const pa=a.pages()[0], pb=b.pages()[0];
    await pa.goto(`${baseURL}/`);
    const signOut=pa.getByRole('button',{name:/sign out/i});
    if(await signOut.count()){ await signOut.click(); }
    await pb.reload(); await expect(pb).toHaveURL(/\/$/);
  } finally { await a.close(); await b.close(); }
});

test('production invalid credentials are rejected without creating a session', async ({ page }) => {
  await page.goto(`${baseURL}/login`);
  await page.getByPlaceholder('Email').fill(`invalid-${Date.now()}@example.invalid`);
  await page.getByPlaceholder(/Password/i).fill('definitely-wrong-password');
  await page.getByRole('button', { name: /sign in with email/i }).click();
  await expect(page).toHaveURL(/\/login/);
  const cookies=await page.context().cookies();
  expect(cookies.some(c=>c.name.includes('session_token'))).toBeFalsy();
});

test('production signup creates a session and survives reload', async ({ page }) => {
  test.skip(!signupEmail || !signupPassword, 'Set E2E_SIGNUP_EMAIL and E2E_SIGNUP_PASSWORD for disposable signup coverage.');
  await page.goto(`${baseURL}/login`);
  await page.getByRole('button', { name: /new traveler\? create account/i }).click();
  await page.getByPlaceholder('Display name').fill('Production E2E');
  await page.getByPlaceholder('Email').fill(signupEmail!);
  await page.getByPlaceholder(/Password/i).fill(signupPassword!);
  await page.getByRole('button', { name: /create account/i }).click();
  await expect(page).toHaveURL(/\/$/);
  await page.reload(); await expect(page).toHaveURL(/\/$/);
});
