# V43 — Complete Prisma PostgreSQL migration

V43 closes the V43 auth-only gap: Prisma now owns the **complete application
persistence schema**, not just the four Better Auth tables.

## What changed

- Better Auth uses the Prisma adapter.
- All app tables from the former SQL migration set are represented in
  `prisma/schema.prisma`.
- The application SQL facade now executes through `PrismaClient.$queryRawUnsafe`;
  Kysely and PGlite are no longer runtime dependencies.
- `DATABASE_URL` is required in local, preview, and production environments.
- The Prisma migration is idempotent and additive for V42 adoption.
- `db:preflight` rejects incompatible existing column types before migration.
- `db:verify` checks the live PostgreSQL schema after migration.
- `db:auth-smoke` performs real signup -> database -> signin -> session coverage.
- `npm run build` is build-only; it never runs database migrations.
- `npm run db:migrate` is the explicit database release step.

## Migration history

- `20260915000000_auth_init`: initial Prisma Better Auth adoption.
- `20260915010000_full_app_adoption`: complete application schema adoption and
  additive V42 compatibility.

Prisma's `_prisma_migrations` is the authoritative migration history. The old
`migrations/*.sql` files are retained only as historical compatibility fixtures
for older QA scripts; they are no longer executed by the application or deploy
build.

## Known environment requirement

The release archive must be installed in an environment that can reach the npm
registry at least once to generate/update `package-lock.json` for the newly added
Prisma packages. This build environment could not resolve `registry.npmjs.org`, so
an updated lockfile could not be regenerated here without inventing package
checksums. The source manifest is correct; run `npm install` in the connected
release environment and commit the resulting lockfile before `npm ci` production
builds.
