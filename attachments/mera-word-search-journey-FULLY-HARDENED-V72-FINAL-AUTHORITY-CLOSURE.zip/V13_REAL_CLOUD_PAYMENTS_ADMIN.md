# V13 — Real Cloud + Payments + Admin integration

Implemented from V12 as an integration pass.

- Cloud saves now expose a server revision and use an optimistic concurrency check when pushing.
- Cloud Sync UI can pull the latest save or push against the last known revision; remote changes produce a conflict instead of silent overwrite.
- Payment entitlements are stored server-side. The browser can read its own entitlements, while purchase verification remains behind a server/provider boundary.
- Admin metrics are exposed through an authenticated, server-side admin function gated by `ADMIN_USER_IDS`.
- Admin notes have a database audit table and server-side access check.
- No payment/provider secret or admin user list is shipped to the client.

## Deployment configuration

Set `ADMIN_USER_IDS` on the server to a comma-separated list of trusted user IDs. Configure the payment provider webhook separately and perform signature verification server-side before recording verified purchases.

## Verification

Run `node scripts/v13-check.mjs`. Full typecheck/build still depends on the project's installed npm dependency set and deployment environment.
