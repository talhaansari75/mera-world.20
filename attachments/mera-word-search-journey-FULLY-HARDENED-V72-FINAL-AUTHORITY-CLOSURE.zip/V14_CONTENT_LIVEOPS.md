# V14 — Content + 15 Languages + LiveOps Expansion

V14 is a real integration pass built on V13.

## Integrated
- 15 supported language entries: en, ur, ur-Latn, hi, ar, bn, pa, sd, ps, tr, es, fr, de, zh, ja.
- Language/content screen is reachable from More and changes the existing persisted game language.
- Each language has direction metadata and sample vocabulary.
- UI localization remains backed by the existing `src/lib/game/i18n.ts` packs.
- LiveOps now has daily, weekly and seasonal challenge cycles with local persistence.
- Existing game event bus feeds V14 word-found and level-complete progress.
- Rewards are credited through the existing Zustand save/economy path.

## Deliberate boundary
The project does **not** claim that every word in the 5000+ bank has been professionally translated into all 15 languages. V14 exposes the 15-language matrix and native sample vocabulary while retaining the existing offline shared word bank where a complete native dictionary is not present.

LiveOps is local-first. A deployed remote-config/event service can replace or augment the local challenge definitions later.
