/** V7 domain module: platform/backoff. */
export type BackoffId = string;
export interface BackoffRecord { id: BackoffId; createdAt: number; version: number }
export function createBackoff(id: BackoffId): BackoffRecord {
  if (!id.trim()) throw new Error("id_required");
  return { id, createdAt: Date.now(), version: 1 };
}
export function isValidBackoff(value: unknown): value is BackoffRecord {
  if (!value || typeof value !== "object") return false;
  const v = value as Record<string, unknown>;
  return typeof v.id === "string" && v.id.length > 0 && typeof v.version === "number";
}
