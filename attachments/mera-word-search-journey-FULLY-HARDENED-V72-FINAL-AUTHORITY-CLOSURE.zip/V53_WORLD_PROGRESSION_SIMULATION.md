# V53 — World Progression Simulation Test

Added an automated campaign simulation for the V52 six-world journey.

## Coverage

- Verifies exactly six journey worlds and their level boundaries.
- Traverses every level from 1 through 2000 in order.
- Confirms each world becomes available only after the previous world boundary.
- Confirms each world's final level is its boss gate.
- Confirms the boss result completes the world and reaches 100% journey progress.
- Confirms a world chest is blocked before boss completion.
- Confirms the chest grants the configured coins/diamonds exactly once.
- Confirms chest inventory keys are persisted in the simulated save.
- Confirms a second chest claim is rejected (idempotency).
- Confirms the final world never advances beyond the 2000-level campaign cap.

## Run

```bash
npm run test:journey
```

The test is also included by the project's existing `npm test` glob for `src/**/*.test.ts`.
