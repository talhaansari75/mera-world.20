# V61 Security Final Closure

## Fixes
- World Boss rewards now use a permanent per-user/per-boss idempotency key: `boss-reward:<userId>:<bossLevel>`.
- Starting an already-defeated World Boss is rejected server-side.
- Boss victory uses the same permanent key, preventing fresh combat sessions from farming the same boss reward.
- Bonus-word submissions now canonicalize forward/reverse paths, preventing reverse-path duplicate farming.
- Added regression tests for both invariants.

## Verification
- 14 targeted game/security tests passed.
- Preview script syntax check passed.
- No schema change was required because the existing unique reward-ledger idempotency key provides the durable uniqueness constraint.

Full dependency-backed production build/typecheck remains environment-dependent when `node_modules` is absent.
