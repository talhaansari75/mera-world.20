# V32 — Adaptive Challenge

Adds a deterministic, privacy-first local adaptive difficulty profile derived from existing gameplay stats. It recommends a level offset and training modes without sending additional player data. The feature is integrated into ScreenId, GameApp routing, and the More menu.

Production note: recommendations are client-side guidance, not authoritative difficulty enforcement.
