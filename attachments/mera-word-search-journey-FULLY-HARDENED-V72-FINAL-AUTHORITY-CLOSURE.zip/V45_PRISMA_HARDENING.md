# V45 Prisma Complete Hardening

Implemented from the V44 critical-gap review.

## Fixed in this release

- Removed application `getSql()` facade and all `$queryRawUnsafe` usage from `src/`.
- Converted application persistence paths (leaderboards, cloud saves, rate limits, audit, idempotency, multiplayer, telemetry, creator, payments, push, moderation, admin, rewards) to Prisma Client CRUD/transactions.
- Added relational User foreign keys for user-owned domain models.
- Added CreatorProfile + Role + UserRole relational foundation.
- Retired executable legacy `migrations/*.sql`; Prisma is now the only executable migration system.
- Replaced the previous `CREATE TABLE IF NOT EXISTS` adoption migration with a fresh-database Prisma baseline migration.
- Added Prisma CLI schema-diff gates for exact live-schema verification and destructive-drift refusal.
- Added reviewed adoption-migration generator for existing databases.
- Added mandatory backup-command gate for production migration.
- Added concurrency smoke test.
- Removed database mutation from build.
- Added explicit policy blocking `prisma db push` in release workflow documentation/scripts.
- Added production migration runbook covering backup, baseline resolution, credentials, rollback and drift handling.

## Verification performed in this build environment

- Application source architecture scan: PASS — no `getSql()` or `$queryRawUnsafe` references.
- JavaScript syntax checks for migration/verification scripts: PASS.
- package.json parse: PASS.
- Prisma Client runtime tests were not executable here because dependencies were not installed and npm registry access timed out/unavailable. No fake test result is claimed.
- `package-lock.json` could not be regenerated for the same network reason; generate it on a networked CI/release runner with `npm install`, then use `npm ci` for reproducible deployments.

## Important production constraint

V42/V43 live databases must be adopted through the documented baseline/diff procedure. This release intentionally refuses blind reconciliation of incompatible data or destructive drift. A reviewed migration is required for type changes, data normalization, obsolete-column removal, duplicate cleanup, or other destructive changes.
