# V65 Player Behavior Engine

V65 introduced a local, privacy-first behavior profile. It uses only in-game signals and can be disabled.
