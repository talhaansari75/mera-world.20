# V47 Prisma Production Hardening

## Non-negotiable lifecycle

### Fresh database
1. `npm ci`
2. `npx prisma generate`
3. `npx prisma migrate deploy`
4. `npm run db:verify`
5. `npm run db:auth-smoke`

### Existing V42/V43 database
The fresh baseline is **never** an adoption migration. Do not run it as reconciliation.

1. Take a real PostgreSQL backup.
2. Restore that backup into an isolated verification database.
3. Run `prisma migrate diff --from-url ... --to-schema-datamodel prisma/schema.prisma --script`.
4. Generate and review the reconciliation SQL; do not auto-apply it.
5. Run full row-count/primary-key digest reconciliation.
6. Run semantic data validation.
7. Apply the reviewed reconciliation migration to a staging clone.
8. Run Prisma verification + application/auth E2E.
9. Only after staging passes, resolve the fresh baseline as applied on the already-reconciled production database.

`db:adopt:plan` never mutates the database. `db:adopt:resolve` is history bookkeeping only after the live schema is already equal to Prisma.

## Backup
Hashing an artifact is not restore verification. Production release requires an isolated restore command and post-restore verification command.

## Rollback
No automatic down-migration is assumed. Rollback is either a tested forward corrective migration or restoration of the verified pre-migration backup.

## Concurrency
Idempotency claims are unique-key based and are never automatically stolen after a timeout. A crashed worker leaves a recoverable pending record; recovery must be explicit so a non-idempotent external side effect is never executed twice merely because a lease expired.

## Ads monetization (V51)
- Google AdSense H5 Games Ads / H5 Ad Placement API is the selected web-game ad network.
- Interstitial placement is only at the completed-level -> next-level transition.
- `ad_free` entitlement suppresses the placement.
- Recurring entitlement expiry is represented by `entitlements.expires_at`.
- Publisher ID remains deployment configuration (`VITE_ADSENSE_PUBLISHER_ID`); no fake ID is committed.
