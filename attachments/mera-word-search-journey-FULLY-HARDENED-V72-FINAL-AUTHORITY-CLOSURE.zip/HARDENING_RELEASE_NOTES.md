# Hardened Release Candidate

This package applies the security fixes from the code audit.

## Fixed / mitigated
- Cloud saves no longer overwrite server-owned progression fields on existing accounts.
- Initial cloud sync rejects non-empty server-owned progression so a client cannot establish forged economy/progression as trusted server state.
- Server reward claims remain isolated from client-only progression; do not use client save data as an authoritative reward source.
- Browser leaderboard and daily-score submission is disabled until a server-verified gameplay session exists; forged scores can no longer be inserted through these functions.
- Creator "publish" now creates/updates `pending_review`; only the moderation workflow can approve/publish content.
- Entitlement reads must be treated as active only when `expiresAt` is null or in the future; payment verification remains server-side/admin/provider controlled.
- Legacy V5 `501 Not Implemented` routes are explicitly retired with HTTP 410 instead of masquerading as production APIs.

## Remaining deployment dependency
A real payment provider still requires provider credentials and a signed webhook handler. This archive deliberately does not invent or fake a payment gateway. The secure behavior is to fail closed until the provider is configured.

A fully authoritative gameplay economy requires a server gameplay-session endpoint that validates deterministic puzzle sessions and awards progression transactionally. Client-only saves are therefore not accepted as a source of truth for rewards.
