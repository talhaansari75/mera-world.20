# Third-Party Notices

## CMU Pronouncing Dictionary

V19 includes a filtered static word bank derived from the CMU Pronouncing Dictionary (cmudict).

CMU's dictionary is distributed under its permissive license terms. This project does not include pronunciation data; it uses a filtered spelling-only subset for offline word-search content.

Source project: Carnegie Mellon University Pronouncing Dictionary (CMUdict).
