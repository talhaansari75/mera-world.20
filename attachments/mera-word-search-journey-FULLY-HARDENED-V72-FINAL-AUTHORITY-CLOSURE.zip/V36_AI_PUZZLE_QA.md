# V36 — AI Puzzle QA Lab

Adds a server-bound Puzzle QA Lab for Creator word sets.

## What is implemented
- Deterministic local audit for word count, length diversity, short-word dominance and recognizability signals.
- Optional server-side xAI audit using the existing `XAI_API_KEY` boundary.
- Strict server validation and bounded issue/suggestion output.
- Graceful local fallback when AI is unavailable, malformed, or rejected.
- Dedicated `Puzzle QA Lab` screen with score, issues, suggestions, and source indicator.
- Direct navigation from AI Puzzle Lab to QA.

## Security boundary
The xAI key is read only on the server. No API key is shipped to the browser and no new telemetry is added.

## QA
- Screen/routing/menu integration: PASS (static)
- Server secret boundary: PASS (static)
- Input sanitization and bounded output: PASS (static)
- Local fallback path: PASS (static)
