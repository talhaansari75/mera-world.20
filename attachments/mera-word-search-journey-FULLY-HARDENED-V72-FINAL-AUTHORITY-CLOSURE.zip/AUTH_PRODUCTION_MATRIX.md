# Production auth verification matrix

The browser E2E job is deliberately deployment-gated by `vars.PRODUCTION_E2E_ENABLED` and the `E2E_*` secrets. A skipped job is not a passing production-auth test.

Required disposable credentials:

- `E2E_BASE_URL`
- `E2E_TEST_EMAIL`
- `E2E_TEST_PASSWORD`
- optionally `E2E_SIGNUP_EMAIL` / `E2E_SIGNUP_PASSWORD`

The suite covers email sign-in, cookie/session establishment, reload persistence, and disposable sign-up. OAuth is intentionally not marked green unless a provider-specific deployment test is enabled separately.

For password reset/email verification, use a disposable mailbox in the deployment environment and test: request -> token delivery -> expiry rejection -> successful change/verification -> old session invalidation -> new session. Do not use production customer mailboxes for E2E.
