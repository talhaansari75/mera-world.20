# V46 Production Prisma Runbook

## Existing V42/V43 database (adoption)

**Never** run the fresh baseline against an existing V42/V43 database.

1. Put the application in maintenance/read-only mode.
2. Verify `DATABASE_URL` points to the intended PostgreSQL database and production TLS is enabled.
3. Take a provider snapshot and/or `pg_dump` backup. Run `npm run db:backup` and independently verify the artifact.
4. Run `npm run db:data:snapshot`.
5. Run `npm run db:adopt:plan`. This creates `artifacts/prisma-adoption/schema-diff.sql` and `data-audit.json` and applies nothing.
6. Review the SQL. Extra objects/columns, incompatible types, nullability changes, unique/FK/index changes and data conflicts require an explicit reviewed reconciliation migration.
7. Apply the reviewed reconciliation migration in a maintenance window.
8. Run `npm run db:verify` and `npm run db:data:verify`.
9. Run `npm run db:adopt:resolve` with `ALLOW_EXISTING_DB_RESOLVE=true` and `BACKUP_VERIFIED=true`. This only records the Prisma baseline as applied; it does not execute the fresh baseline.
10. Run auth and application smoke tests before traffic is restored.

## Fresh database

`npm run db:migrate` is permitted only for a genuinely empty database. The migration guard refuses to run the fresh baseline when existing users are detected.

## Failure / rollback

Prisma migrations are forward-only. There is no automatic down migration. If a reviewed migration fails:

- stop the rollout;
- preserve the failed migration logs and DB state;
- if data/schema is unsafe, restore the verified pre-migration backup into an isolated database first and verify it;
- either restore production from that backup according to the provider's approved procedure, or write/apply a corrective forward migration;
- rerun `db:verify`, data snapshot verification, auth smoke and application smoke before reopening traffic.

## Backup restore drill

Set `DATABASE_RESTORE_VERIFY_COMMAND` to a provider-specific command that restores the backup into an isolated database and runs Prisma/schema/application checks. `npm run db:backup:restore-verify` refuses to pass without that command.

## Deployment order

`backup -> restore verification -> migration guard -> prisma migrate deploy -> schema/data verification -> auth/application smoke -> application rollout`.

Build is never a database migration step.
