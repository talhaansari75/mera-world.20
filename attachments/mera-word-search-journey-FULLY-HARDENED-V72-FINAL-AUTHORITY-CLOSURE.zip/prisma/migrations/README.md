# V46 Prisma migration policy

## One source of truth
`prisma/schema.prisma` is the application schema source of truth. The only executable migration history is `prisma/migrations/`.

## Fresh database
`20260915020000_prisma_fresh_baseline` is a **fresh/empty database baseline**. It must never be used to reconcile an existing V42/V43 database.

## Existing V42/V43 database
Existing databases require a separate adoption plan:

1. `npm run db:adopt:plan`
2. inspect `artifacts/prisma-adoption/schema-diff.sql` and `data-audit.json`
3. take and verify a provider snapshot/pg_dump
4. review/apply the generated reconciliation migration
5. verify counts, IDs, constraints, indexes and semantic invariants
6. only then run `npm run db:adopt:resolve`

`db:adopt:resolve` only marks the fresh baseline as applied after an exact live-schema diff is empty. It never executes the baseline DDL on an existing database.

## Production
- Never use `prisma db push`.
- Never run `prisma migrate deploy` against a legacy database until its Prisma baseline is resolved.
- Build never mutates the database.
- Migration and application rollout are separate stages.
- Destructive changes require a reviewed forward migration or verified backup restore; Prisma does not provide automatic down migrations.
