-- V46 FRESH Prisma baseline.
-- Prisma-controlled enum domains for finite business states.
DO $$ BEGIN CREATE TYPE game_mode AS ENUM ('classic','timed','survival','blitz','zen','daily','endless','fog','mirror','category','boss','rush','precision','hardcore','double_reward','no_hints','small_grid','giant_grid','reverse_only','diagonal','orthogonal','chaos','streak','treasure','nightmare','focus','speedrun','marathon','random_rules'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE idempotency_status AS ENUM ('pending','completed'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE multiplayer_room_status AS ENUM ('open','playing','closed'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE multiplayer_member_role AS ENUM ('host','player'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE moderation_report_status AS ENUM ('open','reviewing','resolved','rejected'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE purchase_status AS ENUM ('pending','verified','failed','refunded'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE currency_code AS ENUM ('USD','EUR','GBP','PKR'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE entitlement_source AS ENUM ('purchase','grant','refund','migration','promo'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE creator_puzzle_status AS ENUM ('draft','pending_review','approved','published','rejected','archived'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- This file is executable only for an empty database. Existing V42/V43 databases
-- must use the explicit adoption plan/resolution flow; this migration never
-- reconciles a live legacy schema.
-- SOURCE 0001_auth.sql
-- Better Auth schema for the local PGLite preview fallback only.
-- Deployed PostgreSQL auth is managed by Prisma under prisma/migrations/.
create table "user" (
  "id" text not null primary key,
  "name" text not null,
  "email" text not null unique,
  "emailVerified" boolean not null,
  "image" text,
  "createdAt" timestamptz default CURRENT_TIMESTAMP not null,
  "updatedAt" timestamptz default CURRENT_TIMESTAMP not null
);
create table "session" (
  "id" text not null primary key,
  "expiresAt" timestamptz not null,
  "token" text not null unique,
  "createdAt" timestamptz default CURRENT_TIMESTAMP not null,
  "updatedAt" timestamptz not null,
  "ipAddress" text,
  "userAgent" text,
  "userId" text not null references "user" ("id") on delete cascade
);
create table "account" (
  "id" text not null primary key,
  "accountId" text not null,
  "providerId" text not null,
  "userId" text not null references "user" ("id") on delete cascade,
  "accessToken" text,
  "refreshToken" text,
  "idToken" text,
  "accessTokenExpiresAt" timestamptz,
  "refreshTokenExpiresAt" timestamptz,
  "scope" text,
  "password" text,
  "createdAt" timestamptz default CURRENT_TIMESTAMP not null,
  "updatedAt" timestamptz not null
);
create table "verification" (
  "id" text not null primary key,
  "identifier" text not null,
  "value" text not null,
  "expiresAt" timestamptz not null,
  "createdAt" timestamptz default CURRENT_TIMESTAMP not null,
  "updatedAt" timestamptz default CURRENT_TIMESTAMP not null
);
create index "session_userId_idx" on "session" ("userId");
create index "account_userId_idx" on "account" ("userId");
create index "verification_identifier_idx" on "verification" ("identifier");


-- SOURCE 0002_game.sql
-- Cloud save, leaderboards, and daily challenge scores.
create table player_saves (
  user_id    text primary key,
  save_json  text not null,
  version    integer not null default 1,
  revision   bigint not null default 1,
  updated_at timestamptz not null default now()
);

create table leaderboard_scores (
  id           serial primary key,
  user_id      text not null,
  display_name text not null,
  board        text not null,
  score        integer not null,
  meta_json    text,
  created_at   timestamptz not null default now()
);
create index leaderboard_board_score_idx
  on leaderboard_scores (board, score desc, created_at asc);
create index leaderboard_user_board_idx
  on leaderboard_scores (user_id, board);

create table daily_results (
  user_id      text not null,
  day_key      text not null,
  score        integer not null,
  time_ms      integer not null,
  stars        integer not null default 0,
  display_name text not null,
  created_at   timestamptz not null default now(),
  primary key (user_id, day_key)
);
create index daily_results_day_score_idx
  on daily_results (day_key, score desc, time_ms asc);


-- SOURCE 0003_v3_platform.sql
-- V3 production platform: idempotency, rate limits, audit, analytics, multiplayer rooms, moderation, purchases.
create table idempotency_keys (
  user_id text not null,
  key text not null,
  operation text not null,
  response_json jsonb not null,
  status text not null default 'pending',
  locked_at timestamptz,
  created_at timestamptz not null default now(),
  primary key (user_id, key)
);
create index idempotency_created_idx on idempotency_keys(created_at);

create table rate_limit_buckets (
  subject text not null,
  bucket text not null,
  count integer not null default 0,
  reset_at timestamptz not null,
  primary key(subject, bucket)
);

create table audit_events (
  id bigserial primary key,
  user_id text,
  event_type text not null,
  payload_json jsonb not null default '{}',
  ip_hash text,
  created_at timestamptz not null default now()
);
create index audit_user_created_idx on audit_events(user_id, created_at desc);
create index audit_type_created_idx on audit_events(event_type, created_at desc);

create table gameplay_events (
  id bigserial primary key,
  user_id text,
  session_id text,
  event_type text not null,
  payload_json jsonb not null default '{}',
  client_ts bigint,
  created_at timestamptz not null default now()
);
create index gameplay_user_created_idx on gameplay_events(user_id, created_at desc);
create index gameplay_type_created_idx on gameplay_events(event_type, created_at desc);

create table multiplayer_rooms (
  room_id text primary key,
  host_user_id text not null,
  mode text not null,
  state_json jsonb not null default '{}',
  status text not null default 'open',
  max_players integer not null default 4,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index multiplayer_status_idx on multiplayer_rooms(status, updated_at desc);

create table multiplayer_members (
  room_id text not null references multiplayer_rooms(room_id) on delete cascade,
  user_id text not null,
  display_name text not null,
  role text not null default 'player',
  joined_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  primary key(room_id, user_id)
);

create table moderation_reports (
  id bigserial primary key,
  reporter_user_id text not null,
  target_type text not null,
  target_id text not null,
  reason text not null,
  details text not null default '',
  status text not null default 'open',
  created_at timestamptz not null default now()
);
create index moderation_status_idx on moderation_reports(status, created_at desc);

create table purchase_receipts (
  id bigserial primary key,
  user_id text not null,
  provider text not null,
  external_id text not null,
  product_id text not null,
  amount_minor integer not null,
  currency text not null,
  status text not null default 'pending',
  raw_json jsonb not null default '{}',
  created_at timestamptz not null default now(),
  unique(provider, external_id)
);
create index purchase_user_idx on purchase_receipts(user_id, created_at desc);


-- SOURCE 0005_v5_completion.sql
-- V5 domain persistence: additive tables. Apply after existing migrations.
CREATE TABLE game_sessions_v5 (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,level_id INTEGER NOT NULL,seed TEXT NOT NULL,status TEXT NOT NULL,score INTEGER NOT NULL DEFAULT 0,started_at BIGINT NOT NULL,updated_at BIGINT NOT NULL);
CREATE INDEX idx_game_sessions_v5_user ON game_sessions_v5(user_id,updated_at DESC);
CREATE TABLE reward_ledger_v5 (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,idempotency_key TEXT NOT NULL UNIQUE,payload_json TEXT NOT NULL,created_at BIGINT NOT NULL);
CREATE TABLE analytics_events_v5 (id TEXT PRIMARY KEY,user_id TEXT,session_id TEXT,name TEXT NOT NULL,properties_json TEXT NOT NULL,created_at BIGINT NOT NULL);
CREATE INDEX idx_analytics_v5_name_time ON analytics_events_v5(name,created_at DESC);
CREATE TABLE multiplayer_rooms_v5 (id TEXT PRIMARY KEY,mode TEXT NOT NULL,status TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 0,state_json TEXT NOT NULL,created_at BIGINT NOT NULL,updated_at BIGINT NOT NULL);
CREATE TABLE payment_events_v5 (event_id TEXT PRIMARY KEY,event_type TEXT NOT NULL,payload_json TEXT NOT NULL,processed_at BIGINT NOT NULL);
CREATE TABLE audit_events_v5 (id TEXT PRIMARY KEY,actor_id TEXT NOT NULL,action TEXT NOT NULL,target TEXT,metadata_json TEXT NOT NULL,created_at BIGINT NOT NULL);
CREATE TABLE moderation_cases_v5 (id TEXT PRIMARY KEY,reporter_id TEXT,target_id TEXT NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL,created_at BIGINT NOT NULL,updated_at BIGINT NOT NULL);


-- SOURCE 0006_v13_cloud_payments_admin.sql
-- V13: cloud revision safety, payment entitlements, and admin access records.
create table entitlements (
  user_id text not null,
  product_id text not null,
  active boolean not null default true,
  source text not null default 'purchase',
  updated_at timestamptz not null default now(),
  primary key(user_id, product_id)
);
create index entitlements_user_idx on entitlements(user_id, active);
create table admin_audit_notes (
  id bigserial primary key,
  admin_user_id text not null,
  action text not null,
  target text not null default '',
  note text not null default '',
  created_at timestamptz not null default now()
);
create index admin_audit_created_idx on admin_audit_notes(created_at desc);


-- SOURCE 0007_v25_creator_cloud.sql
create table creator_puzzles (
  id text primary key,
  user_id text not null,
  title text not null,
  category text not null,
  words_json jsonb not null,
  status text not null default 'published',
  version integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index creator_puzzles_user_updated_idx on creator_puzzles(user_id, updated_at desc);


-- SOURCE 0008_v26_rewards_creator_community.sql
create table creator_reviews (
 id text primary key default gen_random_uuid()::text,
 puzzle_id text not null references creator_puzzles(id) on delete cascade,
 user_id text not null,
 rating integer not null check (rating between 1 and 5),
 body text not null default '',
 created_at timestamptz not null default now(),
 unique(puzzle_id,user_id)
);
create index creator_reviews_puzzle_idx on creator_reviews(puzzle_id,created_at desc);


-- SOURCE 0008_v30_push_subscriptions.sql
CREATE TABLE push_subscriptions (
  user_id text NOT NULL,
  endpoint text NOT NULL,
  subscription_json jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, endpoint)
);
CREATE INDEX push_subscriptions_user_idx ON push_subscriptions(user_id);

-- Complete fresh-schema objects that are intentionally not part of the legacy
-- V42/V43 SQL history. These are Prisma-owned from V46 onward.

CREATE TABLE creator_profiles (
  user_id text PRIMARY KEY REFERENCES "user"(id) ON DELETE CASCADE,
  display_name text NOT NULL,
  bio text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE roles (id text PRIMARY KEY, name text NOT NULL UNIQUE);
CREATE TABLE user_roles (
  user_id text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,
  role_id text NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  PRIMARY KEY(user_id, role_id)
);
INSERT INTO roles(id,name) VALUES ('player','player'),('creator','creator'),('admin','admin');
CREATE TABLE permissions (id text PRIMARY KEY, name text NOT NULL UNIQUE, description text NOT NULL DEFAULT '');
CREATE TABLE role_permissions (role_id text NOT NULL REFERENCES roles(id) ON DELETE CASCADE, permission_id text NOT NULL REFERENCES permissions(id) ON DELETE CASCADE, PRIMARY KEY(role_id, permission_id));
INSERT INTO permissions(id,name,description) VALUES
 ('profile.read','profile.read','Read profile data'),
 ('profile.write','profile.write','Update own profile'),
 ('creator.publish','creator.publish','Publish creator content'),
 ('creator.moderate','creator.moderate','Moderate creator content'),
 ('multiplayer.host','multiplayer.host','Host multiplayer rooms'),
 ('admin.audit','admin.audit','Read/write privileged audit records')
ON CONFLICT (id) DO NOTHING;
INSERT INTO role_permissions(role_id,permission_id)
SELECT 'player', id FROM permissions WHERE name IN ('profile.read','profile.write','multiplayer.host')
ON CONFLICT DO NOTHING;
INSERT INTO role_permissions(role_id,permission_id)
SELECT 'creator', id FROM permissions WHERE name IN ('profile.read','profile.write','multiplayer.host','creator.publish')
ON CONFLICT DO NOTHING;
INSERT INTO role_permissions(role_id,permission_id)
SELECT 'admin', id FROM permissions
ON CONFLICT DO NOTHING;

-- Business invariants enforced by PostgreSQL, not only application code.
ALTER TABLE player_saves ADD CONSTRAINT player_saves_version_chk CHECK (version >= 1);
ALTER TABLE player_saves ADD CONSTRAINT player_saves_revision_chk CHECK (revision >= 1);
ALTER TABLE multiplayer_rooms ADD CONSTRAINT multiplayer_rooms_capacity_chk CHECK (max_players BETWEEN 2 AND 16);
ALTER TABLE multiplayer_rooms ADD CONSTRAINT multiplayer_rooms_status_chk CHECK (status IN ('open','playing','closed'));
ALTER TABLE multiplayer_members ADD CONSTRAINT multiplayer_members_role_chk CHECK (role IN ('host','player'));
ALTER TABLE moderation_reports ADD CONSTRAINT moderation_reports_status_chk CHECK (status IN ('open','reviewing','resolved','rejected'));
ALTER TABLE purchase_receipts ADD CONSTRAINT purchase_receipts_amount_chk CHECK (amount_minor >= 0);
ALTER TABLE purchase_receipts ADD CONSTRAINT purchase_receipts_currency_chk CHECK (currency ~ '^[A-Z]{3}$');
ALTER TABLE purchase_receipts ADD CONSTRAINT purchase_receipts_status_chk CHECK (status IN ('pending','verified','failed','refunded'));
ALTER TABLE entitlements ADD CONSTRAINT entitlements_source_chk CHECK (source IN ('purchase','grant','refund','migration','promo'));
ALTER TABLE creator_puzzles ADD CONSTRAINT creator_puzzles_status_chk CHECK (status IN ('draft','pending_review','approved','published','rejected','archived'));
ALTER TABLE creator_reviews ADD CONSTRAINT creator_reviews_rating_chk CHECK (rating BETWEEN 1 AND 5);
ALTER TABLE daily_results ADD CONSTRAINT daily_results_stars_chk CHECK (stars BETWEEN 0 AND 3);
ALTER TABLE leaderboard_scores ADD CONSTRAINT leaderboard_scores_score_chk CHECK (score >= 0);

-- User relations are added exactly once. No conditional/unconditional duplicate
-- FK creation is used in this fresh baseline.
ALTER TABLE idempotency_keys ADD CONSTRAINT idempotency_status_chk CHECK (status IN ('pending','completed'));
ALTER TABLE player_saves ADD CONSTRAINT player_saves_user_fkey
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE leaderboard_scores ADD CONSTRAINT leaderboard_scores_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE daily_results ADD CONSTRAINT daily_results_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE idempotency_keys ADD CONSTRAINT idempotency_keys_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE audit_events ADD CONSTRAINT audit_events_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE SET NULL;
ALTER TABLE gameplay_events ADD CONSTRAINT gameplay_events_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE SET NULL;
ALTER TABLE multiplayer_rooms ADD CONSTRAINT multiplayer_rooms_host_fk
  FOREIGN KEY (host_user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE multiplayer_members ADD CONSTRAINT multiplayer_members_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE moderation_reports ADD CONSTRAINT moderation_reports_user_fk
  FOREIGN KEY (reporter_user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE purchase_receipts ADD CONSTRAINT purchase_receipts_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE RESTRICT;
ALTER TABLE game_sessions_v5 ADD CONSTRAINT game_sessions_v5_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE reward_ledger_v5 ADD CONSTRAINT reward_ledger_v5_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE analytics_events_v5 ADD CONSTRAINT analytics_events_v5_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE SET NULL;
ALTER TABLE creator_puzzles ADD CONSTRAINT creator_puzzles_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE creator_reviews ADD CONSTRAINT creator_reviews_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE push_subscriptions ADD CONSTRAINT push_subscriptions_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;
ALTER TABLE entitlements ADD CONSTRAINT entitlements_user_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE RESTRICT;
ALTER TABLE admin_audit_notes ADD CONSTRAINT admin_audit_notes_user_fk
  FOREIGN KEY (admin_user_id) REFERENCES "user"(id) ON DELETE CASCADE;

CREATE INDEX moderation_reporter_idx ON moderation_reports(reporter_user_id);
CREATE INDEX reward_ledger_v5_user_idx ON reward_ledger_v5(user_id, created_at DESC);
CREATE INDEX analytics_v5_user_time_idx ON analytics_events_v5(user_id, created_at DESC);
CREATE INDEX admin_audit_user_created_idx ON admin_audit_notes(admin_user_id, created_at DESC);


-- Convert finite-domain text columns to real PostgreSQL enums so schema and DB enforce the same vocabulary.
ALTER TABLE idempotency_keys ALTER COLUMN status DROP DEFAULT;
ALTER TABLE idempotency_keys ALTER COLUMN status TYPE idempotency_status USING status::idempotency_status;
ALTER TABLE idempotency_keys ALTER COLUMN status SET DEFAULT 'pending'::idempotency_status;
ALTER TABLE multiplayer_rooms ALTER COLUMN mode TYPE game_mode USING mode::game_mode;
ALTER TABLE multiplayer_rooms ALTER COLUMN status DROP DEFAULT;
ALTER TABLE multiplayer_rooms ALTER COLUMN status TYPE multiplayer_room_status USING status::multiplayer_room_status;
ALTER TABLE multiplayer_rooms ALTER COLUMN status SET DEFAULT 'open'::multiplayer_room_status;
ALTER TABLE multiplayer_members ALTER COLUMN role DROP DEFAULT;
ALTER TABLE multiplayer_members ALTER COLUMN role TYPE multiplayer_member_role USING role::multiplayer_member_role;
ALTER TABLE multiplayer_members ALTER COLUMN role SET DEFAULT 'player'::multiplayer_member_role;
ALTER TABLE moderation_reports ALTER COLUMN status DROP DEFAULT;
ALTER TABLE moderation_reports ALTER COLUMN status TYPE moderation_report_status USING status::moderation_report_status;
ALTER TABLE moderation_reports ALTER COLUMN status SET DEFAULT 'open'::moderation_report_status;
ALTER TABLE purchase_receipts ALTER COLUMN currency TYPE currency_code USING currency::currency_code;
ALTER TABLE purchase_receipts ALTER COLUMN status DROP DEFAULT;
ALTER TABLE purchase_receipts ALTER COLUMN status TYPE purchase_status USING status::purchase_status;
ALTER TABLE purchase_receipts ALTER COLUMN status SET DEFAULT 'pending'::purchase_status;
ALTER TABLE entitlements ALTER COLUMN source DROP DEFAULT;
ALTER TABLE entitlements ALTER COLUMN source TYPE entitlement_source USING source::entitlement_source;
ALTER TABLE entitlements ALTER COLUMN source SET DEFAULT 'purchase'::entitlement_source;
ALTER TABLE creator_puzzles ALTER COLUMN status DROP DEFAULT;
ALTER TABLE creator_puzzles ALTER COLUMN status TYPE creator_puzzle_status USING status::creator_puzzle_status;
ALTER TABLE creator_puzzles ALTER COLUMN status SET DEFAULT 'published'::creator_puzzle_status;

-- Cross-table multiplayer invariants: a room host must be its host member.
CREATE OR REPLACE FUNCTION enforce_room_host_membership() RETURNS trigger AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM multiplayer_members WHERE room_id = NEW.room_id AND user_id = NEW.host_user_id AND role = 'host') THEN
    RAISE EXCEPTION 'room host must have a host membership';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE CONSTRAINT TRIGGER multiplayer_room_host_membership_fk
AFTER INSERT OR UPDATE OF host_user_id ON multiplayer_rooms
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION enforce_room_host_membership();

CREATE OR REPLACE FUNCTION enforce_room_capacity() RETURNS trigger AS $$
DECLARE member_count integer;
BEGIN
  SELECT count(*) INTO member_count FROM multiplayer_members WHERE room_id = NEW.room_id;
  IF member_count > (SELECT max_players FROM multiplayer_rooms WHERE room_id = NEW.room_id) THEN
    RAISE EXCEPTION 'room capacity exceeded';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE CONSTRAINT TRIGGER multiplayer_room_capacity_ck
AFTER INSERT OR UPDATE ON multiplayer_members
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION enforce_room_capacity();
