-- V63: enforce at most one active World Boss session per user/boss.
CREATE UNIQUE INDEX IF NOT EXISTS game_sessions_v5_one_open_boss_per_user_level
ON game_sessions_v5 (user_id, level_id)
WHERE status = 'boss_open';
