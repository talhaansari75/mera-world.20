-- V50: reconcile the fresh baseline with the hardened Prisma schema.
-- Safe on fresh installs and idempotent for environments that already applied the corrected shape.
ALTER TABLE game_sessions_v5 ADD COLUMN IF NOT EXISTS state_json jsonb NOT NULL DEFAULT '{}';
ALTER TABLE reward_ledger_v5 ALTER COLUMN payload_json TYPE jsonb USING CASE WHEN payload_json IS NULL OR payload_json = '' THEN '{}'::jsonb ELSE payload_json::jsonb END;
ALTER TABLE analytics_events_v5 ALTER COLUMN properties_json TYPE jsonb USING CASE WHEN properties_json IS NULL OR properties_json = '' THEN '{}'::jsonb ELSE properties_json::jsonb END;
ALTER TABLE multiplayer_rooms_v5 ALTER COLUMN state_json TYPE jsonb USING CASE WHEN state_json IS NULL OR state_json = '' THEN '{}'::jsonb ELSE state_json::jsonb END;
ALTER TABLE payment_events_v5 ALTER COLUMN payload_json TYPE jsonb USING CASE WHEN payload_json IS NULL OR payload_json = '' THEN '{}'::jsonb ELSE payload_json::jsonb END;
ALTER TABLE audit_events_v5 ALTER COLUMN metadata_json TYPE jsonb USING CASE WHEN metadata_json IS NULL OR metadata_json = '' THEN '{}'::jsonb ELSE metadata_json::jsonb END;
