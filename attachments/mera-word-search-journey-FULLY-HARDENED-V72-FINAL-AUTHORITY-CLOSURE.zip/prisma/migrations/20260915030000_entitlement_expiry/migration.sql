ALTER TABLE "entitlements"
  ADD COLUMN "expires_at" TIMESTAMPTZ;

CREATE INDEX "entitlements_active_expiry_idx"
  ON "entitlements" ("active", "expires_at");
