# V34 — Voice + NLP

Implemented a browser-local voice command layer using the Web Speech API when available.

- Local speech recognition; no audio upload by this feature.
- Language-aware recognition locale for the existing 15-language set.
- Deterministic command parser for navigation and back/home actions.
- Voice Command Center screen and More-menu integration.
- Graceful fallback when browser speech recognition is unavailable.
- Text-to-speech confirmation uses the browser speech synthesis API.

Production boundary: browser support and microphone permissions are platform/browser dependent. This feature is not a cloud speech/AI service.
