# V56 — Daily Challenge Variations

Adds deterministic daily challenge variants to the existing V54/V55 engagement stack.

## Variants
- Speed Day
- Combo Day
- Hidden Word Day
- Ice Day
- Bomb Day
- Perfect Day
- Treasure Day

The variant is selected deterministically from the UTC day key, displayed on the Daily screen, and contributes a bounded reward multiplier to daily completion rewards.

The challenge object is persisted in the active PlaySession so a day cannot change variation mid-puzzle.

## QA
`dailyChallenges.test.ts` verifies deterministic rotation, complete challenge pool, bounded bonuses and safe fallback behavior.
