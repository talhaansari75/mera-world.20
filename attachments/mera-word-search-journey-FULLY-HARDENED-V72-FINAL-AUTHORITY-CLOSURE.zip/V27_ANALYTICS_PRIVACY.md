# V27 — Player Analytics + Privacy Dashboard

Implemented a local-first analytics dashboard derived from existing PlayerStats.

- Win rate, perfect-clear rate, words/game, average session length, hints/game
- Bosses, daily completions, streaks and completed levels
- Aggregated CSV export
- Explicit privacy messaging: dashboard reads local save counters only
- New Analytics route and More-menu entry
- No new database fields or migrations required

This does not claim server-side product analytics. Any remote telemetry remains governed by the existing analytics setting and deployed backend configuration.
