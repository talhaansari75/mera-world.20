# V49 production hardening

## What changed

- Repaired the fresh PostgreSQL baseline: `player_saves.revision` is created exactly once and `push_subscriptions` has a complete definition.
- Removed duplicate unique indexes that could create Prisma drift.
- Added database-level checks for save revisions, multiplayer capacity/state/roles, moderation state, payment amount/currency/status, entitlement sources, creator state, ratings, daily stars, and non-negative leaderboard scores.
- Added deferred PostgreSQL multiplayer invariants for host membership and capacity.
- Payment receipts and entitlements now use `RESTRICT` deletion semantics; audit data remains `SET NULL`.
- Added real drift mutation/detection/recovery testing on temporary PostgreSQL databases.
- Added production schema assertions, least-privilege checks, query-plan capture, retention-policy registration, DB observability snapshot, and auth database expiry/index checks.
- Added explicit stale-idempotency inventory/recovery tooling without automatic lease stealing.
- Added an explicit read-only legacy adoption rehearsal that emits schema diff/inventory artifacts and never mutates the legacy database.
- Expanded concurrency testing to duplicate signup, duplicate purchase, optimistic save, leaderboard inserts, idempotency, and session token races.
- Added deployed-browser sign-in/session/reload and disposable signup E2E gates.
- CI now verifies the lockfile through npm's resolver before `npm ci`, then runs the complete PostgreSQL gates and isolated backup/restore.

## What CI can and cannot prove

The CI workflow proves the above against a disposable PostgreSQL 16 service and, when the deployment secrets are configured, against the actual deployed browser endpoint. It cannot prove a particular production database's data compatibility unless `LEGACY_ADOPTION_ENABLED=true` and the real read-only legacy/target URLs are supplied.

The npm lockfile is checked by npm itself in CI. This workspace cannot truthfully claim that a public-registry `npm ci` completed during ZIP construction when registry access is unavailable; CI is the authoritative registry verification gate.

## Operational policies

- Do not automatically steal stale idempotency leases. Reconcile external side effects first, then use the explicit recovery tool.
- Do not delete payment/audit records as part of ordinary user deletion. Anonymize or use a retention/legal-hold process.
- Use a separate migration role with DDL privileges and an application role without schema `CREATE` in production.
- Treat query-plan output as a workload gate once production-like fixtures exist; set `REJECT_SEQ_SCAN=true` only when a sequential scan is genuinely unacceptable for the tested query.
- Partition high-volume event tables only after measured volume/retention thresholds justify it.
