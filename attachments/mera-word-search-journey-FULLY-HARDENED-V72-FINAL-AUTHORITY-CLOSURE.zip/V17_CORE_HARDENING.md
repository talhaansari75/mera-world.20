# V17 — Network, Offline Sync & Integrity Hardening

This pass closes a high-priority infrastructure batch without claiming production deployment.

## Implemented
- Persistent local offline queue with bounded size, deduplication, exponential retry backoff and online gating.
- AbortController-based request timeout/retry helper.
- Network state helper.
- Clock-offset estimation from a server timestamp and bounded duration helper.
- Deterministic lightweight action checksum/canonicalization for client-side integrity diagnostics.
- Public V17 platform barrel exports.
- Dependency-free static V17 core check.

## Boundary
The queue is infrastructure and must be connected to each individual server mutation before that mutation is considered reliably offline-capable. Client checksums are not a security boundary; authoritative anti-cheat validation remains server-side.

## Verification
`node scripts/v17-core-check.mjs` passes in the available environment. Full typecheck/build still requires the project's npm dependencies and a production-like environment.
