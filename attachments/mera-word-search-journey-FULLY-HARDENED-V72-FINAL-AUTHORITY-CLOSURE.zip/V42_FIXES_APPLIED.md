# V42 Release Fixes Applied

## Fixed runtime/build-breaking issues

1. Fixed `src/lib/game/contentCoverage.ts` to import the existing puzzle quality implementation from `src/lib/v16/core/puzzleQuality.ts`.
2. Fixed all V5 route imports that incorrectly resolved `lib/v5/api/http` from `src/server/v5/routes/**`.
3. Fixed `src/lib/v4/notifications/scheduler.ts` so its type-only dynamic import resolves `templates.ts` correctly.
4. Enabled the existing Better Auth email/password flow in `.grok/app-env.json` with `VITE_AUTH_ENABLED=true`, so the login/signup UI is reachable in this workspace.
5. Kept `migrations/0001_auth.sql` as the deploy/preview auth migration and verified it remains byte-identical to `migrations/auth/0001_auth.sql`.
6. Updated affected migration/app-env tests to match the intentionally auth-enabled release state.

## Validation

- Local relative-import audit: **0 missing imports**.
- `scripts/v42-release-archive-check.mjs`: **PASS**.
- `scripts/v39-publish-readiness-check.mjs`: **PASS**.
- Migration/app-env/auth invariant tests: **30/30 PASS**.

## Important auth note

The current V42 authentication implementation is **Better Auth + Postgres/PGLite/Kysely**, not Prisma. This archive fixes the existing authentication wiring and enables email/password signup/sign-in; it does **not** replace the auth stack with Prisma.

For a Prisma-specific login/signup implementation, Prisma schema/client setup and the auth data layer would need to be migrated separately.
