# V45 Prisma production runbook

## Guarantees

- `prisma/schema.prisma` is the only executable schema definition.
- Application persistence uses Prisma Client CRUD/transactions; the old `getSql()` facade and `$queryRawUnsafe` are removed from application code.
- `npm run build` never mutates the database.
- `prisma db push` is blocked by project policy; use reviewed migrations only.
- Preflight uses Prisma's migration-diff engine and refuses destructive drift.
- Extra/obsolete live columns are therefore detected as destructive drift and require an explicit reviewed migration.

## Fresh DB

`npm ci` → `npx prisma generate` → verified backup policy → `prisma migrate deploy` → `db:verify` → smoke tests.

## Existing V42/V43 DB

1. Take a provider snapshot and verify it is restorable. Configure `DATABASE_BACKUP_COMMAND` and optionally `DATABASE_BACKUP_VERIFY_COMMAND`.
2. Run `npm run db:preflight`.
3. If the diff contains only reviewed additive changes, set `ALLOW_GENERATE_ADOPTION=true` and run `node scripts/prisma-generate-adoption.mjs`.
4. Review and commit the generated migration. Never auto-approve destructive SQL.
5. Run `prisma migrate deploy`.
6. For a database whose schema already exactly matches the Prisma schema, use `ALLOW_EXISTING_DB_ADOPTION=true npm run db:adopt` to record the baseline without executing DDL.
7. Run `npm run db:verify`, `npm run db:smoke`, `npm run db:auth-smoke`, and `npm run db:concurrency`.

### V43 migration-history reconciliation

V43 may have an old Prisma migration row. Do not edit `_prisma_migrations` manually. Use Prisma's `migrate status` and `migrate resolve` to reconcile the retired migration with the baseline, after backup and schema verification. If Prisma reports a missing migration file, stop and have the release operator reconcile that history before deployment.

## Backup / rollback

A migration is not considered production-ready until the backup command and restore verification succeed. PostgreSQL transactional DDL is used where possible, but rollback is a restore-to-snapshot operation for destructive or data-transforming releases; down migrations are not fabricated.

## Credentials

Use a migration-only DB identity for deployment (DDL permissions) and a separate runtime identity with DML permissions. Do not give the application runtime role ownership or CREATE/ALTER/DROP rights.
