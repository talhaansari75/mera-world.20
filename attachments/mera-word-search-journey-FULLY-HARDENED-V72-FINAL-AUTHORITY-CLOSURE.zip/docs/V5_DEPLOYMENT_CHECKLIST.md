# V5 Deployment Checklist

- [ ] Install dependencies and run `npm run typecheck`.
- [ ] Run project tests plus `tests/v5`.
- [ ] Apply `migrations/0005_v5_completion.sql`.
- [ ] Configure DATABASE_URL and server-only secrets.
- [ ] Configure WebSocket/Redis for authoritative multiplayer.
- [ ] Configure payment provider and verify webhook signatures.
- [ ] Configure AI provider through the server-side adapter only.
- [ ] Configure push notification provider.
- [ ] Configure observability and retention policies.
- [ ] Run staging load/security tests before production.
