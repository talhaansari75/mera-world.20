# Prisma architecture policy

1. Use `getPrisma()` and Prisma Client models for application persistence.
2. Do not add `getSql`, `$queryRawUnsafe`, or a SQL-tag compatibility facade.
3. Raw SQL is not an application persistence escape hatch. Schema inspection belongs to Prisma CLI migration tooling.
4. JSON columns/payloads must be validated at the application boundary with Zod; database JSONB migration is a future reviewed schema change where appropriate.
5. Business status strings remain strings where legacy data compatibility requires them; introducing Prisma enums is a reviewed data migration, not an implicit cast.
6. All user-owned records should have explicit User relations and foreign keys where legacy data can satisfy the constraint.
