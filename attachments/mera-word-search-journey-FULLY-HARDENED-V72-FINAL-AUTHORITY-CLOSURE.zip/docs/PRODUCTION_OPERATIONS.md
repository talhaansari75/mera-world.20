# Production hardening and verification contract

This repository distinguishes **code/CI readiness** from **live-environment proof**. A script existing is not treated as proof until its CI job or production rehearsal executes it.

## Required gates

### Fresh PostgreSQL
`npm ci` → `prisma validate` → `prisma generate` → `prisma migrate deploy` → `db:verify` → drift matrix → backup/restore → concurrency/rate-limit tests.

### Existing PostgreSQL adoption
Set `LEGACY_DATABASE_URL` to a read-only source and `DATABASE_URL` to a disposable isolated target. Set `ADOPTION_TARGET_ISOLATED=true`. The rehearsal clones the legacy DB, generates the actual Prisma reconciliation SQL, applies it to the clone, then re-diffs until the schema diff is empty. The source is never mutated.

Production adoption requires independent backup/restore proof plus explicit `DATA_RECONCILIATION_APPROVED=true`; the gate refuses to silently apply an unreviewed schema change.

### Browser authentication
The `production-auth-e2e` job runs against `E2E_BASE_URL` when `PRODUCTION_E2E_ENABLED=true`. It covers credential sign-in, session persistence, reload, disposable signup, invalid credentials, and independent multi-device sessions.

Email verification/password reset are intentionally hard-gated only when the deployment actually provisions delivery. Set `REQUIRE_EMAIL_VERIFICATION=true` or `REQUIRE_PASSWORD_RESET=true` to make missing Better Auth delivery configuration fail CI.

## Least privilege

The application role must not be superuser, role-creating, database-creating, replication, RLS-bypass, or public-schema-CREATE capable. A separate migration owner/role should own schema objects. Audit sequence usage, function EXECUTE, ownership, default privileges, and role memberships before production cutover.

## Rate limiting

The application limiter is PostgreSQL-backed and uses an atomic `INSERT ... ON CONFLICT` counter update, so multiple app instances share one authoritative counter. `db:rate-limit:race` is a 50-request concurrent race against a limit of 10.

## Query plans and pooling

`db:query-plan` captures `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)` for leaderboard, daily leaderboard, gameplay, audit, purchase, creator, and room queries. Use `REJECT_SEQ_SCAN=true` in a production-like dataset to make sequential scans a hard failure.

`db:pool:smoke` opens concurrent PostgreSQL connections using the configured `connection_limit`/`PRISMA_POOL_MAX`. For serverless deployments, use a managed pooler and size the application pool below the database connection budget.

## Retention / observability / partitioning

Retention policy is recorded for gameplay, audit, purchase, and idempotency data. Audit/payment records are immutable by policy and should be archived before deletion. Partitioning is not forced prematurely; use a documented threshold (for example, sustained multi-million-row growth or query latency regression) and create a reviewed partition migration before the threshold is reached.

`db:observability` is a database health snapshot, not a hosted alerting system. Production must route structured application logs and DB/auth/payment/migration failures to the organization's monitoring/alerting platform.

## Legacy V5

V5 tables are compatibility-only. `db:legacy:v5:audit` blocks removal until runtime source references are zero. Then freeze writes, verify a backup/restore, archive according to retention policy, and use a separate reviewed drop migration.
