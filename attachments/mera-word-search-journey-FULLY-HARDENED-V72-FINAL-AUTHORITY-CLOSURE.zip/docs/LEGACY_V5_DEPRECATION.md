# Legacy V5 deprecation policy

The V5 tables are retained as a compatibility boundary and are **not** a green-light for new application code.

Before removal:
1. `npm run db:legacy:v5:audit` must report zero runtime references.
2. Run the legacy data inventory and confirm the tables are not queried by deployed code, jobs, workers, or external integrations.
3. Freeze writes to the V5 tables and observe one complete retention window.
4. Take and verify a production backup plus isolated restore.
5. Archive/export the V5 data according to the retention policy.
6. Apply a separately reviewed drop migration. Never delete the V5 tables from the fresh baseline merely to make the schema look cleaner.

The current baseline intentionally keeps these models so existing V42/V43 data can be inspected during adoption without an unsafe destructive migration.
