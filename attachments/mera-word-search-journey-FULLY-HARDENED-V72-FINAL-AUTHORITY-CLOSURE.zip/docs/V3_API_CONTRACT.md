# V3 API Contract

## Telemetry
`ingestTelemetry({sessionId, events[]})` accepts at most 100 events per call and is rate-limited server-side.

## Multiplayer
- `createMultiplayerRoom({displayName, mode, maxPlayers, idempotencyKey})`
- `joinMultiplayerRoom({roomId, displayName})`
- `readMultiplayerRoom(roomId)`

Room membership and capacity are authoritative database checks. A future WebSocket transport should call the same service layer instead of duplicating rules.

## Moderation
`submitModerationReport({targetType,targetId,reason,details})` stores a bounded report and creates an audit event.

## Payments
Payment providers must implement `PaymentProvider.verifyWebhook`. No purchase should grant in-game value before server-side verification and idempotent receipt recording.
