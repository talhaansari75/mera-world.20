# V5 API Matrix

All route contracts live under `src/server/v5/routes`. Each endpoint deliberately returns a 501 boundary until its real infrastructure adapter is configured.

The domain modules under `src/lib/v5` are provider-independent and can be tested without network access.
