# Feature Gap Matrix — next implementation target

| Area | Previous workspace | v2 pack | Production integration still needed |
|---|---|---|---|
| Core state/events | Partial | Event bus boundary | Wire every store action to events |
| Network/offline | Partial | Queue/retry/timeout | Persist queue in IndexedDB + server endpoints |
| AI | Partial | Provider router | Secure proxy, provider credentials, schema validator, cache/circuit breaker |
| Levels | Existing generator | 2,000 catalog contract | Generate/publish/validate actual content |
| Settings | Existing small settings model | 485 definitions | Build UI/editor + persistence + migrations |
| Security | Partial | Anti-cheat/config boundaries | Server validation, CSP, rate limits, audit logs |
| Multiplayer | Partial | Authoritative action primitive | WebSocket room service, matchmaking, reconnect, spectator |
| Analytics | Partial | Privacy-safe event buffer | Backend ingestion + retention controls |
| Creator/mods | Partial | Manifest/sanitization | Sandbox/runtime and publishing service |
| Web3 | Optional boundary | Disabled adapter | Optional wallet/on-chain implementation |
| Notifications | Partial | Selection primitive | Push permission, scheduler, backend delivery |
| Performance | Partial | Worker pool | OffscreenCanvas/WebWorker pipeline + profiling |
