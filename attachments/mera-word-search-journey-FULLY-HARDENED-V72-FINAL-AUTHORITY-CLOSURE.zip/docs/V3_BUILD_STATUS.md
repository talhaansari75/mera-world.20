# V3 Platform Build Pack

This version moves the missing-systems work from client-only primitives into server/database boundaries.

## Implemented in this pack
- Database migration for idempotency, rate limits, audit logs, telemetry, multiplayer rooms/members, moderation reports, and verified purchase receipts.
- Server-side idempotency wrapper to make retries safe.
- Database-backed rate limiting.
- Audit-event persistence.
- Server telemetry ingestion with bounded batches and rate limiting.
- Multiplayer room creation/join/read service with server-side capacity checks.
- TanStack server functions exposing telemetry, room operations, and moderation reporting.
- Payment-provider boundary that requires server-side verification before fulfillment.
- Admin dashboard aggregation primitive.
- Input-size sanitization constants.

## Deliberately not faked
Real payment credentials, external payment webhooks, WebSocket infrastructure, Redis/pubsub, object storage/CDN, push provider credentials, production AI providers, app-store signing, and legal/compliance approval remain deployment integrations.

## Security
Never put DATABASE_URL, AI keys, payment secrets, signing keys, or admin secrets into VITE_* variables or browser storage.
