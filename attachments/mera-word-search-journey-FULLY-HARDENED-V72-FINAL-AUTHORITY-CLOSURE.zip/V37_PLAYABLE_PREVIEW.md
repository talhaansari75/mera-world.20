# V37 — Playable Preview Studio

Adds the missing creator handoff between a validated word set and an actual playable puzzle.

## Implemented
- Deterministic local puzzle generation from creator words.
- Structural puzzle validation plus existing quality validator.
- Bounded word sanitization (3–14 A–Z letters, max 12 unique words).
- Responsive board preview and validated target-word list.
- One-click save of a valid preview as an existing Creator Studio draft.
- Navigation from Puzzle QA Lab to Playable Preview Studio.
- Dedicated More-menu entry and GameApp route.
- No new network dependency or client secret exposure.

## QA
- V37 integration check: PASS
- Generator/validator wiring: PASS (static)
- Creator draft handoff: PASS (static)
- Full build/typecheck: not claimed because packaged workspace has no node_modules.
