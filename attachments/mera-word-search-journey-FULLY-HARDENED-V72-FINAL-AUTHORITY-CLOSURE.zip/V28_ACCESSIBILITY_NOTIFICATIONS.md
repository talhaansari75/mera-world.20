# V28 — Accessibility Pro + Smart Notifications

Implemented:
- dedicated Accessibility Pro screen and routing
- accessibility presets: default, low-motion, high-clarity, focus
- screen-reader, dyslexia-friendly, focus-mode preferences
- existing contrast/large-text/color-blind settings surfaced together
- opt-in browser notification permission flow
- smart daily/energy/streak notification candidate selection
- preferred reminder time persisted in save data
- backward-compatible save migration via settings defaults

Production note: browser notifications require user permission and a deployed HTTPS/PWA context where applicable. This client does not claim guaranteed background delivery; a service worker/push backend is still required for reliable scheduled delivery while the app is closed.
