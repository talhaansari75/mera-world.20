# V43 Prisma / PostgreSQL setup

V43 uses **one database engine everywhere: PostgreSQL through Prisma**. Better Auth
and app persistence share the same Prisma PostgreSQL database. The old PGlite/Kysely
runtime path has been removed.

## Required environment

Set `DATABASE_URL` to PostgreSQL before starting the app. Also set the normal
Better Auth variables used by the deployment (`BETTER_AUTH_SECRET`,
`BETTER_AUTH_URL`, and the broker credentials when federated login is enabled).

## New database

```bash
npm install
npx prisma generate
npm run db:migrate
npm run db:smoke
npm run db:auth-smoke
npm run typecheck
npm run build
```

## Existing V42 database

Do **not** run `prisma db push` and do not edit old production tables manually.
Run:

```bash
npm install
npx prisma generate
npm run db:migrate
npm run db:smoke
npm run db:auth-smoke
```

`db:migrate` first runs a non-destructive preflight. Existing overlapping columns
with incompatible PostgreSQL types cause an immediate failure before migration.
Missing additive columns are added by the adoption migration. Existing rows are
never dropped or copied into a second auth database.

The migration also records `_prisma_app_adoption`, while Prisma's own
`_prisma_migrations` table becomes the authoritative migration history.

## Drift / baseline

For an already-populated V42 database, `npm run db:baseline` runs the same guarded
Prisma adoption flow. It does not blindly mark a migration as applied. If the
schema is incompatible, fix the explicit drift and rerun the preflight.

After adoption, use only:

```bash
npx prisma migrate deploy
npm run db:verify
```

Never use `prisma db push` against production.

## Build/deploy rule

`npm run build` **never changes the database**. Database migration is a separate
release step (`npm run db:migrate`). This prevents a frontend build from mutating
production state.

## Auth smoke test

`npm run db:auth-smoke` performs a real Better Auth email/password signup, checks
that Prisma persisted the user/account/session rows, performs a real sign-in, and
requires a session cookie. It then removes only its generated test user.
